data:extend(
    {
        {
            type = "custom-input",
            name = "additional-paste-settings-hotkey",
            key_sequence = "SHIFT + mouse-button-1",
            -- consuming = "none"
            consuming = "none"
        },
        {
            type = "custom-input",
            name = "additional-paste-settings-hotkey-alt",
            key_sequence = "SHIFT + ALT + mouse-button-1",
            consuming = "none"
        }
    }
)
